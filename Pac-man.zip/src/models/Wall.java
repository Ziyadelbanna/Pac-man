package models;
public abstract class Wall {
	public boolean destroyable;
}
