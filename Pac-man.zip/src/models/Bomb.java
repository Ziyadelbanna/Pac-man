package models;
public abstract class Bomb {
	public int damage;
	public int hp;
	
	
	public int getDamage() {
		return this.damage;
	}
	
	
}
