package models;
public abstract class Gift {

}
