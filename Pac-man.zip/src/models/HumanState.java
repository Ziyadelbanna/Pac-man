package models;

public interface HumanState {
	
	public void doAction(Human human);
	public String show();

}
